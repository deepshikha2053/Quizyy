package com.example.quizapp;

public class QuestionAnswer {

    public static String question[] ={
            "Which beverage is my favorite?",
            "Which is my favorite colour?",
            "Which app do I use to stream music?"


    };

    public static String choices[][] = {
            {"Coffee", "Tea", "Cold Drink", "Fruit Juice"},
            {"Black", "Brown", "Blue", "Pink"},
            {"YTmusic", "Gaana", "Wynk", "Spotify"}

    };

    public static String correctAnswers[] = {
            "Coffee",
            "Blue",
            "Spotify"

    };

}
